# Sistema De Agendamento
Sistema de agendamento para avaliação de testes de integração.

1- Criar um teste com InMemoryDatabase para inclusão de agendamentos

2- Criar um teste no padrão stub, utilizando o framework moq, lançando uma exceção na inclusão de agendamentos.

3- criar uma simulação em mock para validar quantas vezes o método de atualizar o agendamento foi chamado ao executar o método GerenciaFimAgendamentoHandler.Execute()

Obs: Lembrem do uso de injeção de dependência!!
Obs²: O projeto de teste já foi criado, basta criar sua classe para teste. Qualquer dúvida procurar um dos instrutores.
