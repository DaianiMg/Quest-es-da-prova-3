﻿namespace SistemaAgendamento.Core.Models
{
    public enum StatusAgendamento
    {
        Criada,
        Concluida,
        Cancelada
    }
}
